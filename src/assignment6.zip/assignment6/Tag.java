package assignment6;

public abstract class Tag {
	
	protected String description;
	
	public  String display() {
		return description;
	}

}
