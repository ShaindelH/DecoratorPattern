package assignment6;

public abstract class DecoratorTag extends Tag {
	
	protected Tag tag;
	
	@Override
	public abstract String display();

}
