package assignment6;

public class Div extends Tag {

	public Div(String text){
		description = "<div>" + text + "</div>";
	}

}
