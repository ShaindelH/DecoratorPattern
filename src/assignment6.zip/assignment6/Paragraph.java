package assignment6;

public class Paragraph extends Tag{

	public Paragraph (String text) {
		description = "<p>" + text + "</p>";
	}
}
