package assignment6;

public class Input extends Tag {

	public Input(String type, String value, String functionName, String function) {
		description = "<input type=\"" + type + "\" " + "value=\"" + value + "\" " + functionName +"=\"" + function +  "\"></input>";
	}
}
