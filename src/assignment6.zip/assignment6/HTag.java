package assignment6;

public class HTag extends Tag{

	public HTag(int hNum, String text) {
		description = "<h" + hNum + ">" + text + "</h" + hNum + ">";
	}

	
	
}
